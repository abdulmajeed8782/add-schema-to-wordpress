<?php
/*
Plugin Name: Custom Schema Plugin
Description: A plugin to add and remove custom schema markup on WordPress pages and posts.
Version: 1.2
Author: Your Name
*/

function custom_schema_meta_box() {
    add_meta_box(
        'custom_schema_meta',
        'Custom Schema Markup',
        'custom_schema_meta_callback',
        ['post', 'page'],
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'custom_schema_meta_box');

function custom_schema_meta_callback($post) {
    $schema_code = get_post_meta($post->ID, '_custom_schema_code', true);
    ?>
    <label for="custom_schema_input">Insert your JSON-LD Schema:</label>
    <textarea id="custom_schema_input" name="custom_schema_input" rows="10" style="width:100%;"><?php echo esc_textarea($schema_code); ?></textarea>
    <br><br>
    <button type="button" id="insert-schema-btn" class="button button-primary">Test Schema and Validate</button>
    <button type="button" id="remove-schema-btn" class="button button-secondary">Remove Schema</button>

    <script>
        document.getElementById('insert-schema-btn').addEventListener('click', function() {
            const schemaInput = document.getElementById('custom_schema_input').value.trim();
            if (schemaInput) {
                // Copy schema code to clipboard
                navigator.clipboard.writeText(schemaInput).then(function() {
                    // Redirect to schema validation tool
                    window.open('https://search.google.com/test/rich-results', '_blank');
                    alert('Schema code copied to clipboard. You will be redirected to the schema validator.');
                }, function(err) {
                    alert('Failed to copy schema to clipboard: ' + err);
                });
            } else {
                alert('Please enter schema code before clicking Insert.');
            }
        });

        document.getElementById('remove-schema-btn').addEventListener('click', function() {
            if (confirm('Are you sure you want to remove the schema?')) {
                document.getElementById('custom_schema_input').value = '';
                alert('Schema has been cleared. Save the post to apply changes.');
            }
        });
    </script>
    <?php
}

function save_custom_schema_data($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!isset($_POST['custom_schema_input'])) return;

    $schema_code = sanitize_textarea_field($_POST['custom_schema_input']);
    update_post_meta($post_id, '_custom_schema_code', $schema_code);
}
add_action('save_post', 'save_custom_schema_data');

function display_custom_schema() {
    if (is_single() || is_page()) {
        global $post;
        $schema_code = get_post_meta($post->ID, '_custom_schema_code', true);
        if (!empty($schema_code)) {
            echo '<script type="application/ld+json">' . $schema_code . '</script>';
        }
    }
}
add_action('wp_footer', 'display_custom_schema');
?>
